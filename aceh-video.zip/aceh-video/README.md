# Aceh 9:16 (1080x1920, 30 FPS)
npm install
npm run dev      # pratinjau di Remotion Studio
npm run render   # -> out/aceh-9x16.mp4 (H.264, yuv420p, CRF 16)

Audio: public/audio/vo.mp3 (45,71 dtk = 1373 frame)
Timing subtitle: src/pages.json (dibuat oleh scripts/make_captions.py)
Jika npm install bermasalah: npx create-video@latest --blank lalu salin src/ dan public/.
