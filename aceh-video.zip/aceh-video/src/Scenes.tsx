import React from 'react';
import {AbsoluteFill, Easing, interpolate, random, useCurrentFrame} from 'remotion';
import {GodRays, Mist, Particles} from './Fx';

export type SceneKind = 1 | 2 | 3 | 4 | 5 | 6;
type Cam = {x: number; y: number; z: number};

type Pal = {
  sky: [string, string, string]; sun: string; sunX: number; sunY: number; sunR: number;
  far: string; mid: string; near: string; ground1: string; ground2: string;
  cloud: string; dark: string; glow: string; ray: string; rayOp: number; stars: boolean;
};

const PAL: Record<SceneKind, Pal> = {
  1: {sky: ['#1f2a5c', '#c76b8f', '#ffc46b'], sun: '#ffe3a0', sunX: 760, sunY: 860, sunR: 120, far: '#6a5a9a', mid: '#44558a', near: '#254a50', ground1: '#2f6a4a', ground2: '#4f9a52', cloud: 'rgba(255,190,170,0.55)', dark: '#14213a', glow: '#ffd27a', ray: 'rgba(255,214,140,0.9)', rayOp: 0.5, stars: true},
  2: {sky: ['#5fb0e6', '#b9e6f2', '#fff3c9'], sun: '#fffbe0', sunX: 220, sunY: 520, sunR: 90, far: '#78b0a8', mid: '#3f8a5a', near: '#2a6b3f', ground1: '#5fae45', ground2: '#a6d95c', cloud: 'rgba(255,255,255,0.8)', dark: '#1d4a30', glow: '#fff3b0', ray: 'rgba(255,248,200,0.9)', rayOp: 0.4, stars: false},
  3: {sky: ['#e8884a', '#ffc983', '#fff0c2'], sun: '#fff6d0', sunX: 860, sunY: 700, sunR: 110, far: '#c98a6a', mid: '#a8654f', near: '#6d3f3a', ground1: '#b88a5a', ground2: '#d8b078', cloud: 'rgba(255,225,190,0.7)', dark: '#3a1f24', glow: '#ffd36a', ray: 'rgba(255,220,150,0.9)', rayOp: 0.45, stars: false},
  4: {sky: ['#4aa4e6', '#a8e0f5', '#fff6d6'], sun: '#fffbe0', sunX: 800, sunY: 460, sunR: 90, far: '#79b09c', mid: '#4d9a58', near: '#336f3f', ground1: '#c9a56a', ground2: '#e3c68a', cloud: 'rgba(255,255,255,0.85)', dark: '#3b2a22', glow: '#ffe08a', ray: 'rgba(255,245,190,0.9)', rayOp: 0.3, stars: false},
  5: {sky: ['#0b0a1f', '#3a1030', '#7a1f2b'], sun: '#ff6a4a', sunX: 790, sunY: 560, sunR: 105, far: '#2a1530', mid: '#1c1024', near: '#120a1a', ground1: '#1a0d18', ground2: '#2a1220', cloud: 'rgba(90,30,50,0.6)', dark: '#07040c', glow: '#ff5a3c', ray: 'rgba(255,90,60,0.5)', rayOp: 0.12, stars: true},
  6: {sky: ['#1d1b4b', '#e0527a', '#ffc46b'], sun: '#fff0b0', sunX: 540, sunY: 1010, sunR: 170, far: '#5b3f7a', mid: '#3a3468', near: '#241f48', ground1: '#1c1840', ground2: '#2b2458', cloud: 'rgba(255,170,150,0.6)', dark: '#0f0c26', glow: '#ffd27a', ray: 'rgba(255,225,150,0.95)', rayOp: 0.65, stars: true},
};

const CAM: Record<SceneKind, {x: [number, number]; y: [number, number]; z: [number, number]}> = {
  1: {x: [0, -30], y: [0, 0], z: [0, 0.12]},
  2: {x: [-70, 70], y: [0, 0], z: [0.04, 0.04]},
  3: {x: [0, 0], y: [40, -20], z: [0, 0.1]},
  4: {x: [80, -80], y: [0, 0], z: [0.03, 0.03]},
  5: {x: [0, 0], y: [0, 0], z: [0.1, 0]},
  6: {x: [0, 0], y: [-70, 50], z: [0.02, 0.09]},
};

// Satu lapisan parallax: depth besar = dekat kamera (bergerak lebih cepat, lebih blur = depth of field)
const Layer: React.FC<{depth: number; cam: Cam; blur?: number; children: React.ReactNode}> = ({depth, cam, blur = 0, children}) => (
  <AbsoluteFill
    style={{
      translate: `${cam.x * depth}px ${cam.y * depth}px`,
      scale: `${1 + cam.z * depth}`,
      filter: blur ? `blur(${blur}px)` : undefined,
    }}
  >
    <svg width={1320} height={2160} viewBox="-120 -120 1320 2160" style={{position: 'absolute', left: -120, top: -120}}>
      {children}
    </svg>
  </AbsoluteFill>
);

const ridge = (seed: number, base: number, amp: number) => {
  let d = `M -140 2040 L -140 ${base}`;
  for (let x = -140; x <= 1220; x += 40) {
    const y = base - amp * (0.55 + 0.3 * Math.sin(x * 0.006 + seed) + 0.15 * Math.sin(x * 0.017 + seed * 2.3));
    d += ` L ${x} ${y.toFixed(1)}`;
  }
  return d + ' L 1220 2040 Z';
};

const Sky: React.FC<{kind: SceneKind; pal: Pal; frame: number}> = ({kind, pal, frame}) => (
  <g>
    <defs>
      <linearGradient id={`sky${kind}`} x1="0" y1="0" x2="0" y2="1">
        <stop offset="0" stopColor={pal.sky[0]} />
        <stop offset="0.55" stopColor={pal.sky[1]} />
        <stop offset="1" stopColor={pal.sky[2]} />
      </linearGradient>
      <radialGradient id={`sun${kind}`}>
        <stop offset="0" stopColor={pal.sun} stopOpacity="1" />
        <stop offset="0.35" stopColor={pal.sun} stopOpacity="0.55" />
        <stop offset="1" stopColor={pal.sun} stopOpacity="0" />
      </radialGradient>
    </defs>
    <rect x={-120} y={-120} width={1320} height={2160} fill={`url(#sky${kind})`} />
    {pal.stars &&
      Array.from({length: 70}, (_, i) => (
        <circle key={i} cx={random(`sx${i}`) * 1080} cy={random(`sy${i}`) * 800} r={1 + random(`sr${i}`) * 2} fill="#fff"
          opacity={0.35 + 0.5 * Math.abs(Math.sin(frame * 0.05 + i))} />
      ))}
    <circle cx={pal.sunX} cy={pal.sunY} r={pal.sunR * 3.2} fill={`url(#sun${kind})`} />
    <circle cx={pal.sunX} cy={pal.sunY} r={pal.sunR} fill={pal.sun} />
  </g>
);

const Clouds: React.FC<{frame: number; color: string; y: number; seed: string}> = ({frame, color, y, seed}) => (
  <g>
    {Array.from({length: 4}, (_, i) => {
      const x = ((random(`${seed}${i}`) * 1500 + frame * (0.3 + i * 0.12)) % 1500) - 210;
      return (
        <g key={i} transform={`translate(${x} ${y + i * 80})`} fill={color}>
          <ellipse cx={0} cy={0} rx={190} ry={34} />
          <ellipse cx={-70} cy={-20} rx={100} ry={30} />
          <ellipse cx={80} cy={-16} rx={110} ry={28} />
        </g>
      );
    })}
  </g>
);

// Istana bergaya Aceh: atap bertingkat, kubah, menara
const Palace: React.FC<{x: number; y: number; s: number; fill: string; glow: string; lit: boolean}> = ({x, y, s, fill, glow, lit}) => (
  <g transform={`translate(${x} ${y}) scale(${s})`}>
    <rect x={-170} y={-120} width={340} height={120} fill={fill} />
    {[-120, -60, 0, 60, 120].map((cx) => (
      <rect key={cx} x={cx - 14} y={-95} width={28} height={70} rx={14} fill={lit ? glow : fill} opacity={lit ? 0.9 : 1} />
    ))}
    <path d="M -230 -120 L -150 -190 L 150 -190 L 230 -120 Q 0 -150 -230 -120 Z" fill={fill} />
    <rect x={-100} y={-290} width={200} height={100} fill={fill} />
    <path d="M -160 -290 L -90 -350 L 90 -350 L 160 -290 Q 0 -315 -160 -290 Z" fill={fill} />
    <path d="M -60 -350 Q 0 -470 60 -350 Z" fill={fill} />
    <rect x={-3} y={-520} width={6} height={80} fill={fill} />
    <circle cx={0} cy={-525} r={9} fill={glow} />
    {[-215, 215].map((tx) => (
      <g key={tx}>
        <rect x={tx - 28} y={-300} width={56} height={300} fill={fill} />
        <path d={`M ${tx - 40} -300 Q ${tx} -420 ${tx + 40} -300 Z`} fill={fill} />
        <circle cx={tx} cy={-420} r={7} fill={glow} />
        {lit && <rect x={tx - 8} y={-230} width={16} height={46} rx={8} fill={glow} />}
      </g>
    ))}
  </g>
);

const Person: React.FC<{x: number; y: number; s: number; fill: string; frame: number; hat?: string; crown?: string; cape?: string; sword?: boolean}> = ({x, y, s, fill, frame, hat, crown, cape, sword}) => (
  <g transform={`translate(${x} ${y}) scale(${s})`}>
    {cape && <path d={`M -30 -135 Q -95 -60 ${-80 + Math.sin(frame * 0.12) * 22} 12 L 22 0 Z`} fill={cape} />}
    <path d="M -30 0 L -22 -120 Q 0 -140 22 -120 L 30 0 Z" fill={fill} />
    <circle cx={0} cy={-148} r={22} fill={fill} />
    {hat && <path d="M -50 -160 L 0 -212 L 50 -160 Z" fill={hat} />}
    {crown && <path d="M -22 -166 L -22 -198 L -10 -182 L 0 -204 L 10 -182 L 22 -198 L 22 -166 Z" fill={crown} />}
    {sword && <rect x={26} y={-230} width={6} height={170} fill="#eef3ff" transform="rotate(28 29 -140)" />}
  </g>
);

const Tree: React.FC<{x: number; y: number; s: number; fill: string; hi: string; frame: number; seed: number}> = ({x, y, s, fill, hi, frame, seed}) => (
  <g transform={`translate(${x} ${y}) scale(${s}) rotate(${Math.sin(frame * 0.03 + seed) * 1.2})`}>
    <rect x={-10} y={-180} width={20} height={180} fill="#3a2a1e" />
    <circle cx={0} cy={-230} r={90} fill={fill} />
    <circle cx={-70} cy={-190} r={65} fill={fill} />
    <circle cx={70} cy={-195} r={70} fill={fill} />
    <circle cx={-25} cy={-262} r={45} fill={hi} opacity={0.5} />
  </g>
);

const Rice: React.FC<{top: number; c1: string; c2: string; frame: number}> = ({top, c1, c2, frame}) => (
  <g>
    {Array.from({length: 9}, (_, r) => {
      const h = 40 + r * 26;
      const y = top + r * 40 + r * r * 8;
      const w = Math.sin(frame * 0.03 + r) * 10;
      return (
        <path key={r} d={`M -140 ${y} Q 300 ${y - 34 + w} 540 ${y} T 1220 ${y} L 1220 ${y + h} L -140 ${y + h} Z`} fill={r % 2 ? c1 : c2} opacity={0.96} />
      );
    })}
  </g>
);

const Grass: React.FC<{frame: number; color: string; n: number; seed: string; hMin: number; hMax: number}> = ({frame, color, n, seed, hMin, hMax}) => (
  <g>
    {Array.from({length: n}, (_, i) => {
      const x = -100 + i * (1300 / n) + random(`${seed}g${i}`) * 40;
      const h = hMin + random(`${seed}h${i}`) * (hMax - hMin);
      const sw = Math.sin(frame * 0.05 + i) * 14;
      return <path key={i} d={`M ${x} 2040 Q ${x + sw} ${2040 - h * 0.6} ${x + sw * 2.2 + 10} ${2040 - h} Q ${x + sw + 14} ${2040 - h * 0.55} ${x + 24} 2040 Z`} fill={color} />;
    })}
  </g>
);

const Stall: React.FC<{x: number; y: number; w: number; c1: string; c2: string; fill: string}> = ({x, y, w, c1, c2, fill}) => (
  <g transform={`translate(${x} ${y})`}>
    <rect x={0} y={-50} width={w} height={50} fill={fill} />
    <rect x={6} y={-170} width={8} height={120} fill={fill} />
    <rect x={w - 14} y={-170} width={8} height={120} fill={fill} />
    {Array.from({length: 6}, (_, i) => {
      const a = (i * (w + 24)) / 6 - 12;
      const b = ((i + 1) * (w + 24)) / 6 - 12;
      return <path key={i} d={`M ${a} -170 L ${b} -170 L ${b} -138 Q ${(a + b) / 2} -118 ${a} -138 Z`} fill={i % 2 ? c1 : c2} />;
    })}
    {[0.2, 0.5, 0.8].map((k, i) => (
      <circle key={i} cx={w * k} cy={-62} r={14} fill={i % 2 ? '#e8503a' : '#f2c14e'} />
    ))}
  </g>
);

const Rumah: React.FC<{x: number; y: number; s: number; fill: string}> = ({x, y, s, fill}) => (
  <g transform={`translate(${x} ${y}) scale(${s})`}>
    {[-70, -35, 0, 35, 70].map((px) => <rect key={px} x={px - 4} y={-60} width={8} height={60} fill={fill} />)}
    <rect x={-90} y={-110} width={180} height={52} fill={fill} />
    <path d="M -120 -108 L -60 -190 L 60 -190 L 120 -108 Q 0 -128 -120 -108 Z" fill={fill} />
  </g>
);

export const Scene: React.FC<{kind: SceneKind; duration: number}> = ({kind, duration}) => {
  const frame = useCurrentFrame();
  const pal = PAL[kind];
  const c = CAM[kind];
  const p = interpolate(frame, [0, duration], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp', easing: Easing.inOut(Easing.ease)});
  const lerp = (a: [number, number]) => a[0] + (a[1] - a[0]) * p;
  const shake = kind === 5 ? {x: Math.sin(frame * 1.7) * 3, y: Math.cos(frame * 2.1) * 3} : {x: 0, y: 0};
  const cam: Cam = {x: lerp(c.x) + shake.x, y: lerp(c.y) + shake.y, z: lerp(c.z)};
  const flash = kind === 5 && frame % 170 > 24 && frame % 170 < 29 ? 0.35 : 0;
  const P = {frame};

  return (
    <AbsoluteFill style={{backgroundColor: pal.sky[0]}}>
      {/* L0: langit + matahari/bulan */}
      <Layer depth={0} cam={cam}>
        <Sky kind={kind} pal={pal} frame={frame} />
      </Layer>

      {/* L1: awan + pegunungan jauh (kabur tipis) */}
      <Layer depth={0.15} cam={cam} blur={2.5}>
        <Clouds frame={frame} color={pal.cloud} y={kind === 6 ? 420 : 330} seed={`c${kind}`} />
        <path d={ridge(kind, 1020, 230)} fill={pal.far} />
      </Layer>
      <Mist color={kind === 5 ? 'rgba(120,30,60,0.5)' : 'rgba(255,235,210,0.55)'} y={940} opacity={kind === 5 ? 0.7 : 0.5} speed={0.5} />

      {/* L2: bukit tengah + objek jauh */}
      <Layer depth={0.35} cam={cam} blur={1.2}>
        <path d={ridge(kind * 2.1, 1130, 150)} fill={pal.mid} />
        {kind === 1 && <Palace x={760} y={1140} s={0.5} fill={pal.dark} glow={pal.glow} lit />}
        {kind === 2 && [80, 220, 380, 560, 720, 900, 1020].map((tx, i) => <Tree key={tx} x={tx} y={1150} s={0.55 + (i % 3) * 0.1} fill={pal.dark} hi={pal.near} seed={i} {...P} />)}
        {kind === 3 && <Palace x={200} y={1150} s={0.4} fill={pal.near} glow={pal.glow} lit={false} />}
        {kind === 4 && [140, 520, 900].map((hx, i) => <Rumah key={hx} x={hx} y={1160} s={0.9 + i * 0.05} fill={pal.dark} />)}
        {kind === 5 && <Palace x={820} y={1170} s={0.7} fill={pal.dark} glow={pal.glow} lit={false} />}
        {kind === 6 && <path d={ridge(9.4, 1230, 120)} fill={pal.near} />}
      </Layer>

      {/* L3: subjek utama */}
      <Layer depth={0.7} cam={cam}>
        {kind === 1 && (<><Rice top={1240} c1={pal.ground1} c2={pal.ground2} {...P} />{[160, 330].map((tx, i) => <Tree key={tx} x={tx} y={1330} s={1 + i * 0.2} fill={pal.near} hi={pal.ground2} seed={i} {...P} />)}</>)}
        {kind === 2 && (<><Rice top={1250} c1={pal.ground1} c2={pal.ground2} {...P} /><path d="M 520 1190 C 700 1350 300 1500 560 1700 C 640 1770 720 1830 760 1980 L 560 2040 C 520 1900 400 1820 330 1700 C 200 1480 470 1360 380 1190 Z" fill="#7cd0e8" opacity={0.85} />{[0, 1, 2, 3, 4].map((i) => <ellipse key={i} cx={470 + Math.sin(i * 2) * 60} cy={1380 + i * 120} rx={50} ry={5} fill="#fff" opacity={0.3 + 0.3 * Math.sin(frame * 0.08 + i)} />)}</>)}
        {kind === 3 && (<><rect x={-140} y={1250} width={1360} height={800} fill={pal.ground1} /><Palace x={540} y={1300} s={1.45} fill={pal.dark} glow={pal.glow} lit />{[330, 750].map((fx, i) => <g key={fx}><rect x={fx} y={1000} width={6} height={300} fill={pal.dark} /><path d={`M ${fx + 6} 1005 Q ${fx + 60} ${990 + Math.sin(frame * 0.12 + i) * 14} ${fx + 110} 1020 L ${fx + 110} 1070 Q ${fx + 60} ${1045 + Math.sin(frame * 0.12 + i) * 14} ${fx + 6} 1070 Z`} fill="#c8372d" /></g>)}<Person x={540} y={1560} s={1.25} fill={pal.dark} crown="#ffd36a" cape="#a8262a" {...P} /></>)}
        {kind === 4 && (<><rect x={-140} y={1300} width={1360} height={800} fill={pal.ground1} /><Stall x={40} y={1350} w={300} c1="#e8503a" c2="#fff1d0" fill={pal.dark} /><Stall x={390} y={1350} w={300} c1="#3a8fe8" c2="#fff1d0" fill={pal.dark} /><Stall x={740} y={1350} w={300} c1="#f2b84e" c2="#fff1d0" fill={pal.dark} />{[250, 560, 900].map((px, i) => <Person key={px} x={px} y={1470} s={0.9} fill={i % 2 ? '#3a2a22' : '#2a1f2e'} hat="#c9a050" {...P} />)}{[120, 260, 400].map((px) => <Person key={px} x={px} y={1260} s={0.28} fill={pal.dark} hat="#c9a050" {...P} />)}</>)}
        {kind === 5 && (<><rect x={-140} y={1300} width={1360} height={800} fill={pal.ground1} /><Palace x={440} y={1330} s={1.6} fill={pal.dark} glow={pal.glow} lit={false} /><rect x={398} y={1090} width={20} height={46} rx={10} fill={pal.glow} opacity={0.8 + 0.2 * Math.sin(frame * 0.2)} /></>)}
        {kind === 6 && (<><path d="M 140 2040 L 270 1540 Q 540 1460 810 1540 L 940 2040 Z" fill={pal.dark} /><Person x={540} y={1500} s={1.7} fill={pal.dark} cape="#c8372d" sword {...P} /></>)}
      </Layer>

      {/* cahaya volumetrik */}
      <GodRays x={pal.sunX} y={pal.sunY} color={pal.ray} opacity={pal.rayOp} />
      {kind === 5 && <AbsoluteFill style={{backgroundColor: '#ffe6e0', opacity: flash, mixBlendMode: 'screen'}} />}

      {/* L4: foreground blur (depth of field) */}
      <Layer depth={1.4} cam={cam} blur={7}>
        {kind !== 5 && <Grass frame={frame} color={kind === 6 ? '#0b0920' : pal.dark} n={16} seed={`f${kind}`} hMin={160} hMax={420} />}
        {kind === 5 && (<><Person x={150} y={2000} s={2.6} fill="#05020a" sword {...P} /><Person x={960} y={2040} s={3} fill="#05020a" {...P} /></>)}
      </Layer>

      <Mist color={kind === 5 ? 'rgba(140,30,60,0.55)' : 'rgba(255,240,220,0.5)'} y={1380} opacity={kind === 5 ? 0.8 : 0.4} speed={0.8} />

      {/* partikel */}
      {kind === 5 ? (
        <Particles count={34} color="#ff7a4a" minSize={3} maxSize={8} speed={2.2} seed="ember" opacity={0.9} />
      ) : kind === 6 ? (
        <Particles count={30} color="#fff0b8" minSize={3} maxSize={9} speed={0.6} wind={5} seed="wind6" opacity={0.85} />
      ) : (
        <Particles count={36} color="#fde68a" minSize={3} maxSize={9} speed={0.7} wind={0.6} seed={`dust${kind}`} opacity={0.8} />
      )}
      <Particles count={8} color="#fff" minSize={14} maxSize={26} speed={0.5} wind={1} seed={`bokeh${kind}`} blur={8} opacity={0.35} />
    </AbsoluteFill>
  );
};
