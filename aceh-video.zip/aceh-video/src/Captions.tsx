import React from 'react';
import {AbsoluteFill, Easing, interpolate, useCurrentFrame, useVideoConfig} from 'remotion';
import {loadFont} from '@remotion/google-fonts/Montserrat';
import pages from './pages.json';

const {fontFamily} = loadFont('normal', {weights: ['800'], subsets: ['latin']});

// Subtitle gaya TikTok: maks 4 kata per halaman, kata yang sedang diucapkan di-highlight
export const Captions: React.FC = () => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const t = (frame / fps) * 1000;
  const page = pages.find((p) => t >= p.startMs && t < p.endMs);
  if (!page) return null;

  const local = (t - page.startMs) / 1000;
  const pop = interpolate(local, [0, 0.14], [0, 1], {
    extrapolateRight: 'clamp',
    easing: Easing.out(Easing.cubic),
  });

  return (
    <AbsoluteFill style={{justifyContent: 'flex-end', alignItems: 'center', paddingBottom: 470}}>
      <div
        style={{
          display: 'flex',
          flexWrap: 'wrap',
          justifyContent: 'center',
          gap: '0 24px',
          maxWidth: 920,
          textAlign: 'center',
          fontFamily,
          fontWeight: 800,
          fontSize: 88,
          lineHeight: 1.2,
          opacity: pop,
          translate: `0px ${(1 - pop) * 28}px`,
        }}
      >
        {page.words.map((w, i) => {
          const active = t >= w.startMs && t < w.endMs;
          return (
            <span
              key={i}
              style={{
                display: 'inline-block',
                color: active ? '#FFD23F' : '#FFFFFF',
                scale: active ? '1.1' : '1',
                WebkitTextStroke: '10px rgba(8,10,24,0.9)',
                paintOrder: 'stroke fill',
                textShadow: '0 8px 24px rgba(0,0,0,0.6)',
              }}
            >
              {w.text.replace(/[,.]$/, '')}
            </span>
          );
        })}
      </div>
    </AbsoluteFill>
  );
};
