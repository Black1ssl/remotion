import React from 'react';
import {AbsoluteFill, random, useCurrentFrame} from 'remotion';

const W = 1080;
const H = 1920;
const mod = (v: number, m: number) => ((v % m) + m) % m;

// Debu / bara / daun: partikel deterministik (murni fungsi dari frame)
export const Particles: React.FC<{
  count: number; color: string; minSize: number; maxSize: number; speed: number;
  seed: string; wind?: number; blur?: number; opacity?: number;
}> = ({count, color, minSize, maxSize, speed, seed, wind = 0, blur = 0, opacity = 0.8}) => {
  const frame = useCurrentFrame();
  return (
    <AbsoluteFill style={{pointerEvents: 'none', filter: blur ? `blur(${blur}px)` : undefined}}>
      {Array.from({length: count}, (_, i) => {
        const r = (k: string) => random(`${seed}${k}${i}`);
        const size = minSize + r('s') * (maxSize - minSize);
        const y = mod(r('y') * H - frame * speed * (0.4 + r('v')), H);
        const x = mod(r('x') * W + Math.sin(frame * 0.02 + r('p') * 6.28) * 45 + frame * wind * (0.5 + r('w')), W);
        const tw = 0.5 + 0.5 * Math.sin(frame * 0.07 + r('t') * 6.28);
        return (
          <div
            key={i}
            style={{
              position: 'absolute', left: x, top: y, width: size, height: size, borderRadius: '50%',
              background: color, boxShadow: `0 0 ${size * 4}px ${color}`,
              opacity: opacity * (0.35 + 0.65 * tw),
            }}
          />
        );
      })}
    </AbsoluteFill>
  );
};

// Berkas cahaya volumetrik (god rays)
export const GodRays: React.FC<{x: number; y: number; color: string; opacity: number}> = ({x, y, color, opacity}) => {
  const frame = useCurrentFrame();
  return (
    <AbsoluteFill style={{mixBlendMode: 'screen', pointerEvents: 'none', overflow: 'hidden'}}>
      {Array.from({length: 7}, (_, i) => (
        <div
          key={i}
          style={{
            position: 'absolute', left: x, top: y,
            width: 150 + (i % 3) * 70, height: 2600,
            transformOrigin: '50% 0%',
            translate: '-50% 0px',
            rotate: `${-36 + i * 12 + Math.sin(frame * 0.012 + i) * 2.5}deg`,
            background: `linear-gradient(180deg, ${color} 0%, transparent 85%)`,
            opacity: opacity * (0.55 + 0.45 * Math.sin(frame * 0.03 + i * 1.7)),
            filter: 'blur(28px)',
          }}
        />
      ))}
    </AbsoluteFill>
  );
};

// Kabut tipis yang bergeser
export const Mist: React.FC<{color: string; y: number; opacity: number; speed: number}> = ({color, y, opacity, speed}) => {
  const frame = useCurrentFrame();
  return (
    <AbsoluteFill style={{pointerEvents: 'none', overflow: 'hidden'}}>
      {Array.from({length: 3}, (_, i) => (
        <div
          key={i}
          style={{
            position: 'absolute', left: mod(i * 520 + frame * speed * (1 + i * 0.4), 1800) - 600,
            top: y + i * 90, width: 900, height: 260, borderRadius: '50%',
            background: `radial-gradient(ellipse at center, ${color} 0%, transparent 70%)`,
            opacity: opacity * (0.7 + 0.3 * Math.sin(frame * 0.02 + i)),
            filter: 'blur(30px)',
          }}
        />
      ))}
    </AbsoluteFill>
  );
};
