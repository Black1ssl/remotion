import React from 'react';
import {AbsoluteFill, Sequence, interpolate, staticFile, useCurrentFrame} from 'remotion';
import {Audio} from '@remotion/media';
import {Scene, SceneKind} from './Scenes';
import {Captions} from './Captions';

const FPS = 30;
export const TOTAL_FRAMES = 1373; // audio 45.714 dtk
const OVERLAP = 18; // cross-fade antar adegan

// Batas adegan mengikuti jeda paragraf/kalimat di audio (detik)
const SCENES: {kind: SceneKind; start: number}[] = [
  {kind: 1, start: 0},      // kerajaan Aceh saat fajar
  {kind: 2, start: 8.6},    // sawah, hutan, sungai
  {kind: 3, start: 16.25},  // istana & raja bijaksana
  {kind: 4, start: 21.3},   // pasar & petani
  {kind: 5, start: 31.3},   // pengkhianatan
  {kind: 6, start: 40.6},   // sang pangeran
];

const SceneWrap: React.FC<{index: number; duration: number; kind: SceneKind}> = ({index, duration, kind}) => {
  const frame = useCurrentFrame();
  return (
    <AbsoluteFill
      style={{
        opacity: index === 0 ? 1 : interpolate(frame, [0, OVERLAP], [0, 1], {extrapolateRight: 'clamp'}),
      }}
    >
      <Scene kind={kind} duration={duration} />
    </AbsoluteFill>
  );
};

export const AcehVideo: React.FC = () => {
  const frame = useCurrentFrame();
  return (
    <AbsoluteFill style={{backgroundColor: '#05060f'}}>
      <Audio src={staticFile('audio/vo.mp3')} />
      {SCENES.map((s, i) => {
        const from = Math.round(s.start * FPS);
        const next = SCENES[i + 1] ? Math.round(SCENES[i + 1].start * FPS) : TOTAL_FRAMES;
        const duration = next - from + (SCENES[i + 1] ? OVERLAP : 0);
        return (
          <Sequence key={i} from={from} durationInFrames={duration} name={`Adegan ${i + 1}`}>
            <SceneWrap index={i} duration={duration} kind={s.kind} />
          </Sequence>
        );
      })}
      {/* vignette + gradasi bawah agar subtitle terbaca */}
      <AbsoluteFill
        style={{
          pointerEvents: 'none',
          background:
            'radial-gradient(ellipse at 50% 45%, transparent 55%, rgba(0,0,12,0.55) 100%), linear-gradient(180deg, rgba(0,0,12,0.35) 0%, transparent 18%, transparent 55%, rgba(0,0,12,0.6) 100%)',
        }}
      />
      <Captions />
      {/* fade in/out akhir */}
      <AbsoluteFill
        style={{
          backgroundColor: '#000',
          pointerEvents: 'none',
          opacity: interpolate(frame, [0, 10, TOTAL_FRAMES - 20, TOTAL_FRAMES], [1, 0, 0, 1], {
            extrapolateLeft: 'clamp',
            extrapolateRight: 'clamp',
          }),
        }}
      />
    </AbsoluteFill>
  );
};
