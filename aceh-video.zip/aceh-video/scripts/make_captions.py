import json, re, math
# (teks frasa, mulai detik, selesai detik) — dipetakan dari jeda audio (silencedetect -35dB)
P = [
("Pada zaman dahulu kala,",0.0,1.53),("di tanah Aceh yang indah,",1.83,3.33),
("berdirilah sebuah kerajaan yang terkenal",3.77,5.67),("akan kemakmuran dan kedamaiannya.",5.81,8.17),
("Negeri itu dikelilingi hamparan sawah yang subur,",9.04,11.93),("hutan yang menghijau,",12.34,13.50),
("serta sungai-sungai yang mengalir jernih.",13.83,15.85),
("Rakyat hidup dengan tenteram di bawah kepemimpinan seorang raja yang bijaksana.",16.64,21.00),
("Setiap hari,",21.58,22.37),("pasar dipenuhi aktivitas perdagangan,",22.75,24.98),
("para petani bekerja dengan penuh semangat,",25.33,27.50),("dan kehidupan masyarakat berjalan dengan harmonis.",27.90,30.69),
("Namun,",31.85,32.43),("di balik kemegahan istana dan kedamaian negeri itu,",32.89,35.94),
("tersimpan sebuah kisah besar tentang pengkhianatan,",36.38,39.37),("perjuangan,",39.76,40.52),
("dan seorang pangeran yang kelak akan membuktikan arti",40.83,42.97),("keberanian serta keadilan.",43.48,45.50),
]
def syl(w):
    w=re.sub(r'[^a-z]','',w.lower()); w=w.replace('ai','a').replace('au','a')
    return max(1,len(re.findall(r'[aeiou]',w)))
pages=[]
for text,s,e in P:
    ws=text.split(); wt=[syl(w)+0.35 for w in ws]; tot=sum(wt); t=s; words=[]
    for w,x in zip(ws,wt):
        d=(e-s)*x/tot; words.append({"text":w,"startMs":round(t*1000),"endMs":round((t+d)*1000)}); t+=d
    n=len(ws); k=math.ceil(n/4); sizes=[n//k+(1 if i<n%k else 0) for i in range(k)]; i=0
    for sz in sizes:
        ch=words[i:i+sz]; i+=sz
        pages.append({"startMs":ch[0]["startMs"],"endMs":ch[-1]["endMs"],"words":ch})
for a,b in zip(pages,pages[1:]):
    if b["startMs"]-a["endMs"]<400: a["endMs"]=b["startMs"]
json.dump(pages,open("src/pages.json","w"),ensure_ascii=False,indent=1)
print(len(pages),"halaman; maks kata/halaman =",max(len(p["words"]) for p in pages))
